        <!-- start site-header -->
        <?php include 'header.php'; ?>

        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <h2>Our Services</h2>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start services-section -->
        <section class="services-section services-s1-page-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="section-title">
                            <span>Our services</span>
                            <h2>Services We Provide</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="services-grid clearfix">
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-cloud-computing"></i>
                                </div>
                                <h4><a href="#">IT Management</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-copywriting"></i>
                                </div>
                                <h4><a href="#">Content Engineering</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-capital"></i>
                                </div>
                                <h4><a href="#">Capital Merkating</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-fraud"></i>
                                </div>
                                <h4><a href="#">Data Security</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-security"></i>
                                </div>
                                <h4><a href="#">Cyber security</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-database"></i>
                                </div>
                                <h4><a href="#">Cloud Services</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end services-section -->


        <!-- start news-letter-section -->
        <section class="news-letter-section">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                        <div class="newsletter">
                            <h3>Email Newsletter</h3>
                            <p>Aenean leo ligula porttitor eu consequat vitae eleifend ac enim. Aliquam lorem ante dapibus in viverra quiss consequat vitae</p>
                            <div class="newsletter-form">
                                <form>
                                    <div>
                                        <input type="text" class="form-control">
                                        <button type="submit">Subscribe</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end news-letter-section -->

        <!-- start site-footer -->
        <?php include 'footer.php'; ?>
