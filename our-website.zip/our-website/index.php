        <!-- start site-header -->
        <?php include 'header.php'; ?>

        <!-- start of hero -->
        <section class="hero-slider hero-style-1">
            <div class="hero-container">
                <div class="hero-wrapper">
                    <div class="hero-slide">
                        <div class="slide-inner slide-bg-image" data-background="assets/images/slider/slide-1.jpg">
                            <div class="container">
                                <div data-swiper-parallax="300" class="slide-title">
                                    <h2>We are IT Services Consulting Firm</h2>
                                </div>
                                <div data-swiper-parallax="400" class="slide-text">
                                    <p>Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. </p>
                                </div>
                                <div class="clearfix"></div>
                                <div data-swiper-parallax="500" class="slide-btns">
                                    <a href="#" class="theme-btn">Discover More</a> 
                                </div>
                            </div>
                        </div> <!-- end slide-inner --> 
                    </div> <!-- end swiper-slide -->
                </div>
                <!-- end swiper-wrapper -->
            </div>
        </section>
        <!-- end of hero slider -->


        <!-- start cta-section -->
        <section class="cta-section">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="cta-content">
                            <h4>We have 15 Years of Experience, this does matter. Contact us for your query</h4>
                            <a href="contact.php" class="theme-btn">Contact us</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end cta-section -->


        <!-- start services-section -->
        <section class="services-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="section-title">
                            <span>Our services</span>
                            <h2>Services We Provide</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="services-grid clearfix">
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-cloud-computing"></i>
                                </div>
                                <h4><a href="#">IT Management</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-copywriting"></i>
                                </div>
                                <h4><a href="#">Content Engineering</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-capital"></i>
                                </div>
                                <h4><a href="#">Capital Merkating</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-fraud"></i>
                                </div>
                                <h4><a href="#">Data Security</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-security"></i>
                                </div>
                                <h4><a href="#">Cyber security</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-database"></i>
                                </div>
                                <h4><a href="#">Cloud Services</a></h4>
                                <p>Hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="all-service">
                            <p>If you wnat to know more details about services Please check <a href="our-services.php">All Services</a></p>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end services-section -->


        <!-- start about-section -->
        <section class="about-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-7 col-md-push-5">
                        <div class="section-title-s2">
                            <span>About us</span>
                            <h2>Take a quick tour of about us!</h2>
                        </div>
                        <div class="details">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar</p>
                            <p>Ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar</p>
                            <blockquote>
                                Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc.
                            </blockquote>
                            <div class="quoter">
                                <div class="img-holder">
                                    <img src="assets/images/about-quoter.jpg" alt>
                                </div>
                                <div class="details">
                                    <h5>Lucifter</h5>
                                    <p>Manager of the company</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col col-md-5 col-md-pull-7">
                        <div class="features">
                            <div>
                                <h4> IT Consultancy</h4>
                                <p>Adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem Nam quam </p>
                            </div>
                            <div>
                                <h4> IT Consultancy</h4>
                                <p>Adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem Nam quam </p>
                            </div>
                            <div>
                                <h4> IT Consultancy</h4>
                                <p>Adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem Nam quam </p>
                            </div>
                            <div>
                                <a href="contact.php" class="theme-btn">Start a trial</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end about-section -->


        <!-- start work-process -->
        <section class="work-process section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="work-process-grids clearfix">
                            <div class="grid">
                                <div class="count">01</div>
                                <h3>Converstion with <br>Client</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="grid">
                                <div class="count">02</div>
                                <h3>Find the relevent <br>problem</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="grid">
                                <div class="count">03</div>
                                <h3>Start the <br>project</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="separator"></div>
                        </div>
                    </div>
                </div>
            </div> <!-- end contaienr -->
        </section>
        <!-- end work-process -->


        <!-- start why-choose-us-section -->
        <section class="why-choose-us-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-5 col-md-5">
                        <div class="section-title-s3">
                            <span>Why choose us</span>
                            <h2>Trusted company in IT services</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-lg-offset-1 col-md-7">
                        <div class="text">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="why-choose-grids clearfix">
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-1.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Best IT Industry</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-2.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Cyber security Management</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-3.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Backup and recovery</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end why-choose-us-section -->


        <!-- start our-skill-section -->
        <section class="our-skill-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-7 col-md-offset-5">
                        <div class="section-title-s4">
                            <span>Our skills</span>
                            <h2>Trusted company in IT services and support</h2>
                        </div>
                        <div class="details">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                            <div class="skills">
                                <div class="skill">
                                    <h6>IT solution</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="85"></div>
                                    </div>
                                </div>
                                <div class="skill">
                                    <h6>Cyber security</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="95"></div>
                                    </div>
                                </div>
                                <div class="skill">
                                    <h6>Saticfaction</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="92"></div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end our-skill-section -->


        <!-- start case-study-section -->
        <section class="case-study-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-5 col-md-5">
                        <div class="section-title-s3">
                            <span>CASE STUDIES</span>
                            <h2>Check our latest project,doen for client!</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-lg-offset-1 col-md-7">
                        <div class="text">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->

            <div class="content-area">
                <div class="case-grids projects-slider">
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-1.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-2.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-3.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-4.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-5.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="grid">
                        <div class="inner">
                            <div class="img-holder">
                                <img src="assets/images/latest-projects/img-6.jpg" alt>
                            </div>
                            <div class="details">
                                <div class="info">
                                    <h3><a href="#">IT Project in Canada</a></h3>
                                    <a href="#">View details <i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end case-study-section -->


        <!-- start testimonials-section -->
        <section class="testimonials-section section-padding p-t-0">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="testimonial-grids clearfix">
                            <div class="grid">
                                <div class="quote">
                                    <div class="icon"><i class="fi flaticon-right-quote"></i></div>
                                    <p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus</p>
                                </div>
                                <div class="details">
                                    <h5>Jhon dow</h5>
                                    <span>Manager of Founcation</span>
                                    <div class="img-holder">
                                        <img src="assets/images/testimonials/img-1.jpg" alt>
                                    </div>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="quote">
                                    <div class="icon"><i class="fi flaticon-right-quote"></i></div>
                                    <p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus</p>
                                </div>
                                <div class="details">
                                    <h5>Michel Dow</h5>
                                    <span>Chife of foundtion</span>
                                    <div class="img-holder">
                                        <img src="assets/images/testimonials/img-2.jpg" alt>
                                    </div>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="quote">
                                    <div class="icon"><i class="fi flaticon-right-quote"></i></div>
                                    <p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus</p>
                                </div>
                                <div class="details">
                                    <h5>Jain smith</h5>
                                    <span>CEO of dahs</span>
                                    <div class="img-holder">
                                        <img src="assets/images/testimonials/img-3.jpg" alt>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end testimonials-section -->


        <!-- start cta-section-s2 -->
        <section class="cta-section-s2">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="cta-content">
                            <h4>If you have any query about us and our services, then fell free to contact with us</h4>
                            <a href="contact.php" class="theme-btn-s2">Contact us</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end cta-section-s2 -->


        <!-- start blog-section -->
        <section class="blog-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-5 col-md-5">
                        <div class="section-title-s3">
                            <span>Blog</span>
                            <h2>See the latest tips & tricks from our blog!</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-lg-offset-1 col-md-7">
                        <div class="text">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col col-xs-12">
                        <div class="blog-grids">
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-1.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Incredibly visually appealing, it's also mentally appealing</a></h3>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-2.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Technology trends, industry influencers hand </a></h3>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-3.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Entrepreneurs and small owners you get net.</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end blog-section -->


        <!-- start news-letter-section -->
        <section class="news-letter-section">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                        <div class="newsletter">
                            <h3>Email Newsletter</h3>
                            <p>Aenean leo ligula porttitor eu consequat vitae eleifend ac enim. Aliquam lorem ante dapibus in viverra quiss consequat vitae</p>
                            <div class="newsletter-form">
                                <form>
                                    <div>
                                        <input type="text" class="form-control">
                                        <button type="submit">Subscribe</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end news-letter-section -->

        <!-- start site-footer -->
        <?php include 'footer.php'; ?>