        <!-- start site-header -->
        <?php include 'header.php'; ?>

        <!-- start page-title -->
        <section class="page-title">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <h2>About us</h2>
                    </div>
                </div> <!-- end row -->
            </div> <!-- end container -->
        </section>        
        <!-- end page-title -->


        <!-- start features-section -->
        <section class="features-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="feature-grids">
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-atom"></i>
                                </div>
                                <h3>IT industry</h3>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-customer-service"></i>
                                </div>
                                <h3>Fast Services</h3>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-computer"></i>
                                </div>
                                <h3>Desktop Computing</h3>
                            </div>
                            <div class="grid">
                                <div class="icon">
                                    <i class="fi flaticon-client"></i>
                                </div>
                                <h3>IT Consultancy</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end features-section -->


        <!-- start about-section-s2 -->
        <section class="about-section-s2 section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6">
                        <div class="section-title-s3">
                            <span>About us</span>
                            <h2>Take a quick tour of about us!</h2>
                        </div>
                        <div class="details">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar</p>
                            <ul>
                                <li>Adipiscing sem neque sed ipsum. Nam quam </li>
                                <li>Honcus, sem quam semper libero, sit amet adipiscing sem neque</li>
                                <li>Ulamcorper ultricies nisi. Nam eget dui. Etiam rhoncus</li>
                                <li>Maecenas tempus, tellus eget condimentum rhoncus</li>
                            </ul>
                            <a href="#" class="theme-btn-s3">More About us</a>
                        </div>
                    </div>
                    <div class="col col-md-6">
                        <div class="img-holder">
                            <img src="assets/images/about-1.jpg" alt>
                            <img src="assets/images/about-2.jpg" alt>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end about-section-s2 -->


        <!-- start work-process -->
        <section class="work-process section-padding p-t-0">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="work-process-grids clearfix">
                            <div class="grid">
                                <div class="count">01</div>
                                <h3>Converstion with <br>Client</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="grid">
                                <div class="count">02</div>
                                <h3>Find the relevent <br>problem</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="grid">
                                <div class="count">03</div>
                                <h3>Start the <br>project</h3>
                                <p>Quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh.</p>
                            </div>
                            <div class="separator"></div>
                        </div>
                    </div>
                </div>
            </div> <!-- end contaienr -->
        </section>
        <!-- end work-process -->


        <!-- start cta-s2-section -->
        <section class="cta-s2-section">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-8 col-lg-offset-2 col-sm-8 col-sm-offset-2">
                        <div class="cta-details">
                            <div class="video">
                                <a href="#" class="video-btn" data-type="iframe" tabindex="0"><i class="fi flaticon-play-button"></i></a>
                            </div>
                            <h4>If you have any query, thene fell free to contact with us</h4>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end cta-s2-section -->


        <!-- start why-choose-us-section -->
        <section class="why-choose-us-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-5 col-md-5">
                        <div class="section-title-s3">
                            <span>Why choose us</span>
                            <h2>Trusted company in IT services</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-lg-offset-1 col-md-7">
                        <div class="text">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="why-choose-grids clearfix">
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-1.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Best IT Industry</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-2.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Cyber security Management</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-holder">
                                    <img src="assets/images/why-choose/img-3.jpg" alt>
                                </div>
                                <div class="details">
                                    <h3>Backup and recovery</h3>
                                    <a href="#"><i class="fi flaticon-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end why-choose-us-section -->


        <!-- start our-skill-section -->
        <section class="our-skill-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-md-7 col-md-offset-5">
                        <div class="section-title-s4">
                            <span>Our skills</span>
                            <h2>Trusted company in IT services and support</h2>
                        </div>
                        <div class="details">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                            <div class="skills">
                                <div class="skill">
                                    <h6>IT solution</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="85"></div>
                                    </div>
                                </div>
                                <div class="skill">
                                    <h6>Cyber security</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="95"></div>
                                    </div>
                                </div>
                                <div class="skill">
                                    <h6>Saticfaction</h6>
                                    <div class="progress">
                                        <div class="progress-bar" data-percent="92"></div>
                                    </div>
                                </div>
                            </div>                        
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end our-skill-section -->


        <!-- start team-section -->
        <section class="team-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-4 col-lg-offset-4 col-sm-6 col-sm-offset-3">
                        <div class="section-title-s5">
                            <span>Members</span>
                            <h2>Our Dedicated Tem <span>For your service</span></h2>
                        </div>                        
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="team-grids">
                            <div class="grid">
                                <div class="img-social">
                                    <div class="img-holder">
                                        <img src="assets/images/team/img-1.jpg" alt>
                                    </div>
                                    <div class="social">
                                        <ul>
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="details">
                                    <h3>Jodra Adil</h3>
                                    <span>Managing Director</span>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-social">
                                    <div class="img-holder">
                                        <img src="assets/images/team/img-2.jpg" alt>
                                    </div>
                                    <div class="social">
                                        <ul>
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="details">
                                    <h3>Willum Biala</h3>
                                    <span>Site Manager</span>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-social">
                                    <div class="img-holder">
                                        <img src="assets/images/team/img-3.jpg" alt>
                                    </div>
                                    <div class="social">
                                        <ul>
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="details">
                                    <h3>Sahim Mcildi</h3>
                                    <span>Testing Manager</span>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="img-social">
                                    <div class="img-holder">
                                        <img src="assets/images/team/img-4.jpg" alt>
                                    </div>
                                    <div class="social">
                                        <ul>
                                            <li><a href="#"><i class="ti-facebook"></i></a></li>
                                            <li><a href="#"><i class="ti-twitter-alt"></i></a></li>
                                            <li><a href="#"><i class="ti-linkedin"></i></a></li>
                                            <li><a href="#"><i class="ti-pinterest"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="details">
                                    <h3>Jhain dow</h3>
                                    <span>Cheif Officer</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end team-section -->


        <!-- start pricing-section -->
        <section class="pricing-section section-padding p-t-0">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-6 col-lg-offset-3">
                        <div class="section-title-s6">
                            <span>Pricing</span>
                            <h2>Choose Your Best Plan</h2>
                            <p>Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="pricing-grids clearfix">
                            <div class="grid">
                                <div class="pricing-header">
                                    <h4>Basic</h4>
                                    <p>tellus eget condimentum rhoncus, sem quam semper libero</p>
                                    <div class="price">
                                        <h3>$45.99 <span>/ mo</span></h3>
                                    </div>
                                </div>
                                <div class="pricing-body">
                                    <ul>
                                        <li><i class="ti-check"></i> Nullam quis ante. Etiam sit amet orci </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                        <li><i class="ti-check"></i> Etiam sit amet orci eget eros faucibus </li>
                                        <li><i class="ti-check"></i> Etiam ultricies nisi vel augue </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                    </ul>
                                </div>
                                <div class="pricing-footer">
                                    <a href="#" class="theme-btn">Choose plan</a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="pricing-header">
                                    <h4>Most Populer</h4>
                                    <p>tellus eget condimentum rhoncus, sem quam semper libero</p>
                                    <div class="price">
                                        <h3>$75.99 <span>/ mo</span></h3>
                                    </div>
                                </div>
                                <div class="pricing-body">
                                    <ul>
                                        <li><i class="ti-check"></i> Nullam quis ante. Etiam sit amet orci </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                        <li><i class="ti-check"></i> Etiam sit amet orci eget eros faucibus </li>
                                        <li><i class="ti-check"></i> Etiam ultricies nisi vel augue </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                    </ul>
                                </div>
                                <div class="pricing-footer">
                                    <a href="#" class="theme-btn">Choose plan</a>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="pricing-header">
                                    <h4>Premium</h4>
                                    <p>tellus eget condimentum rhoncus, sem quam semper libero</p>
                                    <div class="price">
                                        <h3>$99.99 <span>/ mo</span></h3>
                                    </div>
                                </div>
                                <div class="pricing-body">
                                    <ul>
                                        <li><i class="ti-check"></i> Nullam quis ante. Etiam sit amet orci </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                        <li><i class="ti-check"></i> Etiam sit amet orci eget eros faucibus </li>
                                        <li><i class="ti-check"></i> Etiam ultricies nisi vel augue </li>
                                        <li><i class="ti-check"></i> Leo eget bibendum sodales </li>
                                    </ul>
                                </div>
                                <div class="pricing-footer">
                                    <a href="#" class="theme-btn">Choose plan</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- container -->
        </section>
        <!-- end pricing-section -->


        <!-- start testimonials-section-s2 -->
        <section class="testimonials-section-s2 section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="testimonial-grids testimonials-slider">
                            <div class="grid">
                                <div class="client-info">
                                    <div class="client-pic">
                                        <img src="assets/images/testimonials/img-1.jpg" alt>
                                    </div>
                                    <h4>Jhon Dow</h4>
                                    <span>Manager of Founcation</span>
                                </div>
                                <div class="client-quote">
                                    <p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncusDonec vitae sapien ut libero venenatis faucibusDonec vitae sapien ut libero venenatis </p>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="client-info">
                                    <div class="client-pic">
                                        <img src="assets/images/testimonials/img-2.jpg" alt>
                                    </div>
                                    <h4>Jain michel</h4>
                                    <span>Manager of Founcation</span>
                                </div>
                                <div class="client-quote">
                                    <p>Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncusDonec vitae sapien ut libero venenatis faucibusDonec vitae sapien ut libero venenatis </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end testimonials-section-s2 -->


        <!-- start cta-section-s2 -->
        <section class="cta-section-s2">
            <div class="container">
                <div class="row">
                    <div class="col col-xs-12">
                        <div class="cta-content">
                            <h4>If you have any query about us and our services, then fell free to contact with us</h4>
                            <a href="contact.php" class="theme-btn-s2">Contact us</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- end cta-section-s2 -->


        <!-- start blog-section -->
        <section class="blog-section section-padding">
            <div class="container">
                <div class="row">
                    <div class="col col-lg-5 col-md-5">
                        <div class="section-title-s3">
                            <span>Blog</span>
                            <h2>See the latest tips & tricks from our blog!</h2>
                        </div>
                    </div>
                    <div class="col col-lg-6 col-lg-offset-1 col-md-7">
                        <div class="text">
                            <p>Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel</p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col col-xs-12">
                        <div class="blog-grids">
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-1.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Incredibly visually appealing, it's also mentally appealing</a></h3>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-2.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Technology trends, industry influencers hand </a></h3>
                                </div>
                            </div>
                            <div class="grid">
                                <div class="entry-media">
                                    <img src="assets/images/blog/img-3.jpg" alt>
                                </div>
                                <div class="details">
                                    <div class="entry-meta">
                                        <ul>
                                            <li>13 Jul, 2019</li>
                                            <li>5 Comments</li>
                                        </ul>
                                    </div>
                                    <h3><a href="#">Entrepreneurs and small owners you get net.</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end blog-section -->


        <!-- start news-letter-section -->
        <section class="news-letter-section">
            <div class="container">
                <div class="row">
                    <div class="col col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
                        <div class="newsletter">
                            <h3>Email Newsletter</h3>
                            <p>Aenean leo ligula porttitor eu consequat vitae eleifend ac enim. Aliquam lorem ante dapibus in viverra quiss consequat vitae</p>
                            <div class="newsletter-form">
                                <form>
                                    <div>
                                        <input type="text" class="form-control">
                                        <button type="submit">Subscribe</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- end container -->
        </section>
        <!-- end news-letter-section -->

        <!-- start site-footer -->
        <?php include 'footer.php'; ?>